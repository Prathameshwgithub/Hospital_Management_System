# Hospital_Management_System

This Hospital Management System project is a computerized hospital front desk management that produces user-friendly, quick, and cost-effective software. It handles and secures patient information, diagnosis data, and so on. This was done by hand and its’ principal job is to register and maintain patient information and to access and update the information when needed. Patient information and diagnosis are entered into the system, then the output is used to display these details on the screen. 
The information is easily accessible. For personal usage, the data is well-protected, and the data processing is quick.
